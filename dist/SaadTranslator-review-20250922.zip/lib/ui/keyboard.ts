// Re-export from unified shortcuts module to prevent duplication
export * from './shortcuts';